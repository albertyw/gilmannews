-- MySQL dump 10.11
--
-- Host: localhost    Database: gnews_adpo1
-- ------------------------------------------------------
-- Server version	5.0.51a-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `poll_comment`
--

DROP TABLE IF EXISTS `poll_comment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_comment` (
  `com_id` int(9) NOT NULL auto_increment,
  `poll_id` int(9) NOT NULL default '0',
  `time` int(11) NOT NULL default '0',
  `host` varchar(70) NOT NULL default '',
  `browser` varchar(70) NOT NULL default '',
  `name` varchar(60) NOT NULL default '',
  `email` varchar(70) NOT NULL default '',
  `message` text NOT NULL,
  PRIMARY KEY  (`com_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_comment`
--

LOCK TABLES `poll_comment` WRITE;
/*!40000 ALTER TABLE `poll_comment` DISABLE KEYS */;
INSERT INTO `poll_comment` (`com_id`, `poll_id`, `time`, `host`, `browser`, `name`, `email`, `message`) VALUES (2,7,1174278865,'pool-71-127-159-140.bltmmd.fios.verizon.net','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2) Gecko/2007','Albert','admin@gilmannews.com','Athletic achievement should be spread out during more than one assembly.');
/*!40000 ALTER TABLE `poll_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_config`
--

DROP TABLE IF EXISTS `poll_config`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_config` (
  `config_id` smallint(5) unsigned NOT NULL auto_increment,
  `base_gif` varchar(60) NOT NULL default '',
  `lang` varchar(20) NOT NULL default '',
  `title` varchar(60) NOT NULL default '',
  `vote_button` varchar(30) NOT NULL default '',
  `result_text` varchar(40) NOT NULL default '',
  `total_text` varchar(40) NOT NULL default '',
  `voted` varchar(40) NOT NULL default '',
  `send_com` varchar(40) NOT NULL default '',
  `img_height` int(5) NOT NULL default '0',
  `img_length` int(5) NOT NULL default '0',
  `table_width` varchar(6) NOT NULL default '',
  `bgcolor_tab` varchar(7) NOT NULL default '',
  `bgcolor_fr` varchar(7) NOT NULL default '',
  `font_face` varchar(70) NOT NULL default '',
  `font_color` varchar(7) NOT NULL default '',
  `type` varchar(10) NOT NULL default '0',
  `check_ip` smallint(2) NOT NULL default '0',
  `lock_timeout` int(9) NOT NULL default '0',
  `time_offset` varchar(5) NOT NULL default '0',
  `entry_pp` int(4) unsigned NOT NULL default '0',
  `poll_version` varchar(5) NOT NULL default '0',
  `base_url` varchar(100) NOT NULL default '',
  `result_order` varchar(20) NOT NULL default '',
  `def_options` smallint(3) unsigned NOT NULL default '0',
  `polls_pp` int(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`config_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_config`
--

LOCK TABLES `poll_config` WRITE;
/*!40000 ALTER TABLE `poll_config` DISABLE KEYS */;
INSERT INTO `poll_config` (`config_id`, `base_gif`, `lang`, `title`, `vote_button`, `result_text`, `total_text`, `voted`, `send_com`, `img_height`, `img_length`, `table_width`, `bgcolor_tab`, `bgcolor_fr`, `font_face`, `font_color`, `type`, `check_ip`, `lock_timeout`, `time_offset`, `entry_pp`, `poll_version`, `base_url`, `result_order`, `def_options`, `polls_pp`) VALUES (1,'/polls/image','english.php','The Gilman News','Vote','View results','Total votes','You have already voted!','Send comment',10,42,'170','#FFFFFF','#006600','Verdana, Arial, Helvetica, sans-serif','#000000','percent',0,2,'0',5,'2.03','/polls','desc',10,12);
/*!40000 ALTER TABLE `poll_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_data`
--

DROP TABLE IF EXISTS `poll_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_data` (
  `id` int(11) NOT NULL auto_increment,
  `poll_id` int(11) NOT NULL default '0',
  `option_id` int(11) NOT NULL default '0',
  `option_text` varchar(100) NOT NULL default '',
  `color` varchar(20) NOT NULL default '',
  `votes` int(14) NOT NULL default '0',
  PRIMARY KEY  (`poll_id`,`option_id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_data`
--

LOCK TABLES `poll_data` WRITE;
/*!40000 ALTER TABLE `poll_data` DISABLE KEYS */;
INSERT INTO `poll_data` (`id`, `poll_id`, `option_id`, `option_text`, `color`, `votes`) VALUES (21,4,1,'Fail to make the playoffs','blank',0),(22,4,2,'Lose in the first or second round','blank',9),(23,4,3,'Lose in the Conference Championship','blank',11),(24,4,4,'Lose in the Superbowl','blank',4),(25,4,5,'Going all the way - Win the Superbowl','blank',22),(33,6,3,'No Preference','blank',6),(32,6,2,'No','blank',52),(31,6,1,'Yes','blank',43),(34,7,1,'Athletic assemblies are good and should be kept as is','blank',8),(35,7,2,'Athletic assemblies are essential but they need amending','blank',9),(36,7,3,'Eliminate athletic assemblies but find some other way to recognize athletes','blank',4),(37,7,4,'There is no need for special recognition of athletes each season','blank',3),(38,7,5,'There is no need for special recognition of athletes at all','blank',11),(39,8,1,'Its Great!','blank',5),(40,8,2,'Its OK.','blank',2),(41,8,3,'It sucks.','blank',3),(42,8,4,'Its summer?','blank',7),(43,9,1,'I\'ve seen the movie and read the book','blank',12),(44,9,2,'I\'ve seen the movie','blank',2),(45,9,3,'I\'ve read the book','blank',2),(46,9,4,'I haven\'t seen either','blank',3),(47,9,5,'I don\'t want to see either','blank',3),(48,10,1,'I love them','blank',1),(49,10,2,'Meh','blank',6),(50,10,3,'They suck','blank',1),(51,11,1,'Yes','blank',183),(52,11,2,'No','blank',8),(53,11,3,'Don\'t Care','blank',15),(54,12,1,'Yes','blank',148),(55,12,2,'No','blank',35),(56,12,3,'Don\'t Care','blank',34);
/*!40000 ALTER TABLE `poll_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_index`
--

DROP TABLE IF EXISTS `poll_index`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_index` (
  `poll_id` int(11) unsigned NOT NULL auto_increment,
  `question` varchar(100) NOT NULL default '',
  `timestamp` int(11) NOT NULL default '0',
  `status` smallint(2) NOT NULL default '0',
  `logging` smallint(2) NOT NULL default '0',
  `exp_time` int(11) NOT NULL default '0',
  `expire` smallint(2) NOT NULL default '0',
  `comments` smallint(2) NOT NULL default '0',
  PRIMARY KEY  (`poll_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_index`
--

LOCK TABLES `poll_index` WRITE;
/*!40000 ALTER TABLE `poll_index` DISABLE KEYS */;
INSERT INTO `poll_index` (`poll_id`, `question`, `timestamp`, `status`, `logging`, `exp_time`, `expire`, `comments`) VALUES (4,'How Do You Think The Ravens Will Fare In The Remainder Of The Season .  This poll has ended.',1164829812,0,0,1184133852,1,0),(6,'Should there be an arts requirement for graduation?',1168965054,0,0,1184793148,1,0),(7,'What do you think about Athletic Assemblies?',1174278522,0,0,1184133877,1,1),(8,'How\'s your summer?',1184133588,0,0,1189461860,1,0),(9,'How is Harry Potter affecting your life?',1184792993,0,0,1190816410,1,0),(10,'How do you like your new classes?',1189461783,0,0,1217379211,1,0),(11,'Do you want wireless access on the Gilman campus?',1190814143,1,0,1190814143,0,0),(12,'Do you want Gilman to have Macs?',1190814198,1,0,1190814198,0,0);
/*!40000 ALTER TABLE `poll_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_ip`
--

DROP TABLE IF EXISTS `poll_ip`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_ip` (
  `ip_id` int(11) NOT NULL auto_increment,
  `poll_id` int(11) NOT NULL default '0',
  `ip_addr` varchar(15) NOT NULL default '',
  `timestamp` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ip_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_ip`
--

LOCK TABLES `poll_ip` WRITE;
/*!40000 ALTER TABLE `poll_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_log`
--

DROP TABLE IF EXISTS `poll_log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_log` (
  `log_id` int(11) unsigned NOT NULL auto_increment,
  `poll_id` int(11) NOT NULL default '0',
  `option_id` int(11) NOT NULL default '0',
  `timestamp` int(11) NOT NULL default '0',
  `ip_addr` varchar(15) NOT NULL default '',
  `host` varchar(70) NOT NULL default '',
  `agent` varchar(80) NOT NULL default '0',
  PRIMARY KEY  (`log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_log`
--

LOCK TABLES `poll_log` WRITE;
/*!40000 ALTER TABLE `poll_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_templates`
--

DROP TABLE IF EXISTS `poll_templates`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_templates` (
  `tpl_id` int(10) unsigned NOT NULL auto_increment,
  `tplset_id` int(10) unsigned NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `template` mediumtext NOT NULL,
  PRIMARY KEY  (`tpl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_templates`
--

LOCK TABLES `poll_templates` WRITE;
/*!40000 ALTER TABLE `poll_templates` DISABLE KEYS */;
INSERT INTO `poll_templates` (`tpl_id`, `tplset_id`, `title`, `template`) VALUES (1,1,'display_head','<table width=\"$pollvars[table_width]\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"$pollvars[bgcolor_fr]\">\r\n  <tr align=\"center\">\r\n    <td>\r\n      <style type=\"text/css\">\r\n <!--\r\n  .input { font-family: $pollvars[font_face]; font-size: 8pt}\r\n -->\r\n</style>\r\n      <font face=\"$pollvars[font_face]\" size=\"-1\" color=\"#FFFFFF\"><b>$pollvars[title]</b></font></td>\r\n  </tr>\r\n  <tr align=\"center\"> \r\n    <td> \r\n      <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\" align=\"center\" bgcolor=\"$pollvars[bgcolor_tab]\">\r\n        <tr> \r\n          <td height=\"40\" valign=\"middle\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><b>$question</b></font></td>\r\n        </tr>\r\n        <tr align=\"right\" valign=\"top\"> \r\n          <td>\r\n            <form method=\"post\" action=\"$this->form_forward\">\r\n              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">\r\n                <tr valign=\"top\" align=\"center\"> \r\n                  <td> \r\n                    <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\">\r\n'),(2,1,'display_loop',' <tr> \r\n   <td width=\"15%\"><input type=\"radio\" name=\"option_id\" value=\"$data[option_id]\"></td>\r\n   <td width=\"85%\"><font face=\"$pollvars[font_face]\" size=\"1\" color=\"$pollvars[font_color]\">$data[option_text]</font></td>\r\n </tr>\r\n'),(3,1,'display_foot','                    </table>\r\n                    <input type=\"hidden\" name=\"action\" value=\"vote\">\r\n                    <input type=\"hidden\" name=\"poll_ident\" value=\"$poll_id\">\r\n                    <input type=\"submit\" value=\"$pollvars[vote_button]\" class=\"input\">\r\n                    <br>\r\n                    <br>\r\n                    <font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><a href=\"$this->form_forward?action=results&amp;poll_ident=$poll_id\">$pollvars[result_text]</a></font>\r\n                  </td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(4,1,'result_head','<table width=\"$pollvars[table_width]\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"$pollvars[bgcolor_fr]\">\r\n<tr align=\"center\">\r\n<td>\r\n<style type=\"text/css\">\r\n<!--\r\n .input { font-family: $pollvars[font_face]; font-size: 8pt}\r\n .links { font-family: $pollvars[font_face]; font-size: 7.5pt; color: $pollvars[font_color]}\r\n-->\r\n</style>\r\n<font face=\"$pollvars[font_face]\" size=\"-1\" color=\"#FFFFFF\"><b>$pollvars[title]</b></font></td>\r\n</tr>\r\n<tr align=\"center\">\r\n <td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\" align=\"center\" bgcolor=\"$pollvars[bgcolor_tab]\">\r\n <tr valign=\"middle\">\r\n   <td height=\"40\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><b>$question</b></font></td>\r\n </tr>\r\n <tr align=\"right\" valign=\"bottom\">\r\n   <td>\r\n     <table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" width=\"100%\" align=\"center\">\r\n       <tr valign=\"top\">\r\n        <td>\r\n         <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\">\r\n'),(5,1,'result_loop','<tr>\r\n    <td height=\"22\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$option_text</font></td>\r\n    <td nowrap height=\"22\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><img src=\"$pollvars[base_gif]/$poll_color.gif\" width=\"$img_width\" height=\"$pollvars[img_height]\"> $vote_val</font></td>\r\n</tr>\r\n'),(6,1,'result_foot','       </table>\r\n       <font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><br>\r\n       $pollvars[total_text]: <font color=\"#CC0000\">$total_votes</font><br>\r\n       $VOTE<br><br><div align=\"center\">\r\n       $COMMENT&nbsp;</div></font>\r\n       </td></tr>\r\n      <tr><td height=\"2\">&nbsp;</td></tr>\r\n     </table>\r\n    <font face=\"$pollvars[font_face]\" size=\"1\"><a href=\"http://www.proxy2.de\" target=\"_blank\" title=\"Advanced Poll\">Version $pollvars[poll_version]</a></font></td>\r\n   </tr>\r\n </table>\r\n</td>\r\n</tr>\r\n</table>\r\n'),(7,1,'comment','<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\" bgcolor=\"#666699\">\r\n  <tr align=\"center\">\r\n    <td>\r\n     <style type=\"text/css\">\r\n      <!--\r\n       .button {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}\r\n       .textarea {  font-family: \"MS Sans Serif\"; font-size: 9pt; width: 195px}\r\n       .input {  width: 195px}\r\n      -->\r\n    </style><font color=\"#FFFFFF\" face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"><b>Send Your Comment</b></font></td>\r\n  </tr>\r\n  <tr>\r\n    <td>\r\n      <table border=\"0\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" bgcolor=\"#FFFFFF\" width=\"200\">\r\n        <tr>\r\n          <td width=\"149\">\r\n            <form method=\"post\" action=\"$this->form_forward\">\r\n              <table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"\" align=\"center\">\r\n                <tr>\r\n                  <td class=\"td1\" height=\"40\"><b><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">$question</font></b></td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Name:</font><br>\r\n                    <input type=\"text\" name=\"name\" maxlength=\"25\" class=\"input\" size=\"23\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">e-mail:</font><br>\r\n                    <input type=\"text\" name=\"email\" size=\"23\" maxlength=\"50\" class=\"input\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Comment(*):</font><br>\r\n                    <font face=\"MS Sans Serif\" size=\"1\">\r\n                    <textarea name=\"message\" cols=\"19\" wrap=\"VIRTUAL\" rows=\"6\" class=\"textarea\"></textarea>\r\n                    </font>\r\n                  </td>\r\n                </tr>\r\n                <tr valign=\"top\">\r\n                  <td>\r\n                    <input type=\"submit\" value=\"Submit\" class=\"button\">\r\n                    <input type=\"reset\" value=\"Reset\" class=\"button\">\r\n                    <input type=\"hidden\" name=\"action\" value=\"add\">\r\n                    <input type=\"hidden\" name=\"id\" value=\"$poll_id\">\r\n                  </td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(8,2,'display_head','<table width=\"$pollvars[table_width]\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" bgcolor=\"#F3F3F3\">\r\n  <tr valign=\"top\"> \r\n    <td valign=\"top\" align=\"right\">\r\n      <form method=\"post\" action=\"$this->form_forward\">\r\n        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">\r\n          <tr bgcolor=\"$pollvars[bgcolor_fr]\"> \r\n            <td colspan=\"2\" height=\"30\"><font face=\"$pollvars[font_face]\" color=\"#FFFFFF\" size=\"1\"><b>\r\n              $question</b></font></td>\r\n          </tr>\r\n'),(9,2,'display_loop','<tr> \r\n    <td width=\"14%\"><input type=\"radio\" name=\"option_id\" value=\"$data[option_id]\"></td>\r\n    <td width=\"86%\"><font face=\"$pollvars[font_face]\" size=\"1\" color=\"$pollvars[font_color]\">$data[option_text]</font></td>\r\n</tr>\r\n'),(10,2,'display_foot','          <tr align=\"center\"> \r\n            <td colspan=\"2\"> \r\n              <input type=\"image\" border=\"0\" src=\"$pollvars[base_gif]/vote.gif\" width=\"110\" height=\"48\">\r\n              <input type=\"hidden\" name=\"action\" value=\"vote\">\r\n              <input type=\"hidden\" name=\"poll_ident\" value=\"$poll_id\">\r\n              <br>\r\n              <font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><a href=\"$this->form_forward?action=results&amp;poll_ident=$poll_id\">$pollvars[result_text]</a>\r\n            </td>\r\n          </tr>\r\n        </table>\r\n      </form>\r\n      <font face=\"$pollvars[font_face]\" size=\"1\"><a href=\"http://www.proxy2.de\" target=\"_blank\" title=\"Advanced Poll\">Version $pollvars[poll_version]</a></font>\r\n     </td>\r\n  </tr>\r\n</table>\r\n'),(11,2,'result_head','<table width=\"170\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" bgcolor=\"#F3F3F3\">\r\n  <tr> \r\n    <td colspan=\"2\" height=\"25\" bgcolor=\"$pollvars[bgcolor_fr]\"><font face=\"$pollvars[font_face]\" color=\"#FFFFFF\" size=\"1\"><b>$question</b></font></td>\r\n  </tr>\r\n\r\n'),(12,2,'result_loop','  <tr> \r\n    <td colspan=\"2\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$option_text</font></td>\r\n  </tr>\r\n  <tr> \r\n    <td width=\"52%\"><img src=\"$pollvars[base_gif]/greenbar.gif\" width=\"$img_width\" height=\"7\"></td>\r\n    <td width=\"48%\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$vote_val</font></td>\r\n  </tr>\r\n'),(13,2,'result_foot','  <tr> \r\n    <td colspan=\"2\" height=\"40\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"> \r\n      $pollvars[total_text]: <font color=\"#CC0000\">$total_votes</font>\r\n      <br>$VOTE</font><br><div align=\"center\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$COMMENT</font></div>\r\n    </td>\r\n  </tr>\r\n  <tr align=\"right\" valign=\"bottom\" height=\"30\"> \r\n    <td colspan=\"2\"><font face=\"$pollvars[font_face]\" size=\"1\"><a href=\"http://www.proxy2.de\" target=\"_blank\" title=\"Advanced Poll\">Version $pollvars[poll_version]</a></font></td>\r\n  </tr>\r\n</table>\r\n'),(14,2,'comment','<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\" bgcolor=\"#666699\">\r\n  <tr align=\"center\">\r\n    <td>\r\n     <style type=\"text/css\">\r\n      <!--\r\n       .button {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}\r\n       .textarea {  font-family: \"MS Sans Serif\"; font-size: 9pt; width: 195px}\r\n       .input {  width: 195px}\r\n      -->\r\n    </style><font color=\"#FFFFFF\" face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"><b>Send Your Comment</b></font></td>\r\n  </tr>\r\n  <tr>\r\n    <td>\r\n      <table border=\"0\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" bgcolor=\"#F3F3F3\" width=\"200\">\r\n        <tr>\r\n          <td width=\"149\">\r\n            <form method=\"post\" action=\"$this->form_forward\">\r\n              <table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"\" align=\"center\">\r\n                <tr>\r\n                  <td class=\"td1\" height=\"40\"><b><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">$question</font></b></td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Name:</font><br>\r\n                    <input type=\"text\" name=\"name\" maxlength=\"25\" class=\"input\" size=\"23\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">e-mail:</font><br>\r\n                    <input type=\"text\" name=\"email\" size=\"23\" maxlength=\"50\" class=\"input\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Comment(*):</font><br>\r\n                    <font face=\"MS Sans Serif\" size=\"1\">\r\n                    <textarea name=\"message\" cols=\"19\" wrap=\"VIRTUAL\" rows=\"6\" class=\"textarea\"></textarea>\r\n                    </font>\r\n                  </td>\r\n                </tr>\r\n                <tr valign=\"top\">\r\n                  <td>\r\n                    <input type=\"submit\" value=\"Submit\" class=\"button\">\r\n                    <input type=\"reset\" value=\"Reset\" class=\"button\">\r\n                    <input type=\"hidden\" name=\"action\" value=\"add\">\r\n                    <input type=\"hidden\" name=\"id\" value=\"$poll_id\">\r\n                  </td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(15,3,'display_head','<table width=\"$pollvars[table_width]\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"$pollvars[bgcolor_fr]\">\r\n  <tr align=\"center\">\r\n    <td>\r\n      <style type=\"text/css\">\r\n <!--\r\n  .input { font-family: $pollvars[font_face]; font-size: 8pt}\r\n -->\r\n</style>\r\n      <font face=\"$pollvars[font_face]\" size=\"-1\" color=\"#FFFFFF\"><b>$pollvars[title]</b></font></td>\r\n  </tr>\r\n  <tr align=\"center\"> \r\n    <td> \r\n      <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\" align=\"center\" bgcolor=\"$pollvars[bgcolor_tab]\">\r\n        <tr> \r\n          <td height=\"40\" valign=\"middle\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><b>$question</b></font></td>\r\n        </tr>\r\n        <tr align=\"right\" valign=\"top\"> \r\n          <td>\r\n            <form method=\"post\" name=\"poll_$poll_id\" onsubmit=\"return poll_results_$poll_id(\'vote\',\'$pollvars[base_url]/popup.php\',\'Poll\',\'500\',\'350\',\'toolbar=no,scrollbars=yes\');\">\r\n              <script language=\"JavaScript\">\r\n<!--\r\nfunction poll_results_$poll_id(action,theURL,winName,winWidth,winHeight,features) {      \r\n    var w = (screen.width - winWidth)/2;\r\n    var h = (screen.height - winHeight)/2 - 20;\r\n    features = features+\',width=\'+winWidth+\',height=\'+winHeight+\',top=\'+h+\',left=\'+w;\r\n    var poll_ident = self.document.poll_$poll_id.poll_ident.value;\r\n    option_id = \'\';\r\n    for (i=0; i<self.document.poll_$poll_id.option_id.length; i++) {\r\n        if(self.document.poll_$poll_id.option_id[i].checked == true) {\r\n            option_id = self.document.poll_$poll_id.option_id[i].value;\r\n            break;\r\n        }\r\n    }\r\n    option_id = (option_id != \'\') ? \'&option_id=\'+option_id : \'\';\r\n    if (action==\'results\' || (option_id != \'\' && action==\'vote\')) {\r\n        theURL = theURL+\'?action=\'+action+\'&poll_ident=\'+poll_ident+option_id;\r\n        poll_popup = window.open(theURL,winName,features);\r\n        poll_popup.focus();\r\n    }\r\n    return false;\r\n}\r\n//-->\r\n        </script>\r\n              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">\r\n                <tr valign=\"top\" align=\"center\"> \r\n                  <td> \r\n                    <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\">\r\n'),(16,3,'display_loop',' <tr> \r\n   <td width=\"15%\"><input type=\"radio\" name=\"option_id\" value=\"$data[option_id]\"></td>\r\n   <td width=\"85%\"><font face=\"$pollvars[font_face]\" size=\"1\" color=\"$pollvars[font_color]\">$data[option_text]</font></td>\r\n </tr>\r\n'),(17,3,'display_foot','                    </table>\r\n                    <input type=\"hidden\" name=\"action\" value=\"vote\">\r\n                    <input type=\"hidden\" name=\"poll_ident\" value=\"$poll_id\">\r\n                    <input type=\"submit\" value=\"$pollvars[vote_button]\" class=\"input\">\r\n                    <br>\r\n                    <br>\r\n                    <font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><a href=\"javascript:void(poll_results_$poll_id(\'results\',\'$pollvars[base_url]/popup.php\',\'Poll\',\'500\',\'350\',\'toolbar=no,scrollbars=yes\'))\">$pollvars[result_text]</a><br>\r\n                    </font></td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n            <font face=\"$pollvars[font_face]\" size=\"1\"><a href=\"http://www.proxy2.de\" target=\"_blank\" title=\"Advanced Poll\">Version $pollvars[poll_version]</a></font>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(18,3,'result_head','<table width=\"450\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"#CCCCCC\">\r\n  <tr>\r\n    <td align=\"center\"> \r\n      <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" bgcolor=\"#F6F6F6\">\r\n        <tr align=\"center\"> \r\n          <td colspan=\"3\" height=\"40\"><font face=\"$pollvars[font_face]\" size=\"1\" color=\"#000000\"><b>$question</b></font></td>\r\n        </tr>\r\n'),(19,3,'result_loop','        <tr>\r\n          <td width=\"3%\">&nbsp;</td>\r\n          <td><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$option_text</font></td>\r\n          <td><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><img src=\"$pollvars[base_gif]/$poll_color.gif\" width=\"$img_width\" height=\"$pollvars[img_height]\"> $vote_percent % ($vote_count)</font></td>\r\n        </tr>\r\n'),(20,3,'result_foot','        <tr> \r\n          <td colspan=\"3\" valign=\"bottom\" align=\"center\"><b><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$pollvars[total_text]: \r\n            $total_votes</font></b></td>\r\n        </tr>\r\n        <tr align=\"center\"> \r\n          <td colspan=\"3\" valign=\"top\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$VOTE \r\n            <br>\r\n            $COMMENT</font></td>\r\n        </tr>\r\n        <tr align=\"right\"> \r\n          <td colspan=\"3\"><font face=\"$pollvars[font_face]\" size=\"1\"><a href=\"http://www.proxy2.de\" target=\"_blank\" title=\"Advanced Poll\">Version $pollvars[poll_version]</a></font></td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(21,3,'comment','<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\" bgcolor=\"#666699\">\r\n  <tr align=\"center\">\r\n    <td>\r\n     <style type=\"text/css\">\r\n      <!--\r\n       .button {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}\r\n       .textarea {  font-family: \"MS Sans Serif\"; font-size: 9pt; width: 195px}\r\n       .input {  width: 195px}\r\n      -->\r\n    </style><font color=\"#FFFFFF\" face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"><b>Submit Your Comment</b></font></td>\r\n  </tr>\r\n  <tr>\r\n    <td>\r\n      <table border=\"0\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" bgcolor=\"#FFFFFF\" width=\"200\">\r\n        <tr>\r\n          <td width=\"149\">\r\n            <form method=\"post\" action=\"$this->form_forward\">\r\n              <table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"\" align=\"center\">\r\n                <tr>\r\n                  <td class=\"td1\" height=\"40\"><b><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">$question</font></b></td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Name:</font><br>\r\n                    <input type=\"text\" name=\"name\" maxlength=\"25\" class=\"input\" size=\"23\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">e-mail:</font><br>\r\n                    <input type=\"text\" name=\"email\" size=\"23\" maxlength=\"50\" class=\"input\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Comment(*):</font><br>\r\n                    <font face=\"MS Sans Serif\" size=\"1\">\r\n                    <textarea name=\"message\" cols=\"19\" wrap=\"VIRTUAL\" rows=\"6\" class=\"textarea\"></textarea>\r\n                    </font>\r\n                  </td>\r\n                </tr>\r\n                <tr valign=\"top\">\r\n                  <td>\r\n                    <input type=\"submit\" value=\"Submit\" class=\"button\">\r\n                    <input type=\"reset\" value=\"Reset\" class=\"button\">\r\n                    <input type=\"hidden\" name=\"action\" value=\"add\">\r\n                    <input type=\"hidden\" name=\"id\" value=\"$poll_id\">\r\n                  </td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(22,4,'display_head','<table width=\"$pollvars[table_width]\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"$pollvars[bgcolor_fr]\">\r\n  <tr align=\"center\">\r\n    <td>\r\n      <style type=\"text/css\">\r\n <!--\r\n  .input { font-family: $pollvars[font_face]; font-size: 8pt}\r\n -->\r\n</style>\r\n      <font face=\"$pollvars[font_face]\" size=\"-1\" color=\"#FFFFFF\"><b>$pollvars[title]</b></font></td>\r\n  </tr>\r\n  <tr align=\"center\"> \r\n    <td> \r\n      <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\" align=\"center\" bgcolor=\"$pollvars[bgcolor_tab]\">\r\n        <tr> \r\n          <td height=\"40\" valign=\"middle\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><b>$question</b></font></td>\r\n        </tr>\r\n        <tr align=\"right\" valign=\"top\"> \r\n          <td>\r\n            <form method=\"post\" action=\"$this->form_forward\">\r\n               <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">\r\n                <tr valign=\"top\" align=\"center\"> \r\n                  <td> \r\n                    <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\">\r\n'),(23,4,'display_loop','<tr> \r\n   <td width=\"15%\"><input type=\"radio\" name=\"option_id\" value=\"$data[option_id]\"></td>\r\n   <td width=\"85%\"><font face=\"$pollvars[font_face]\" size=\"1\" color=\"$pollvars[font_color]\">$data[option_text]</font></td>\r\n </tr>\r\n'),(24,4,'display_foot','                    </table>\r\n                    <input type=\"hidden\" name=\"action\" value=\"vote\">\r\n                    <input type=\"hidden\" name=\"poll_ident\" value=\"$poll_id\">\r\n                    <input type=\"submit\" value=\"$pollvars[vote_button]\" class=\"input\">\r\n                    <br>\r\n                    <br>\r\n                    <font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><a href=\"$this->form_forward?action=results&amp;poll_ident=$poll_id\">$pollvars[result_text]</a><br>\r\n                    </font></td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n            <font face=\"$pollvars[font_face]\" size=\"1\"><a href=\"http://www.proxy2.de\" target=\"_blank\" title=\"Advanced Poll\">Version $pollvars[poll_version]</a></font>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(25,4,'result_head','<table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" width=\"360\">\r\n  <tr> \r\n    <td colspan=\"2\"><font face=\"$pollvars[font_face]\" size=\"2\">$question</font></td>\r\n  </tr>\r\n  <tr> \r\n    <td><img src=\"$pollvars[base_url]/png.php?poll_id=$poll_id\"></td>\r\n    <td> \r\n      <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"#000000\">\r\n        <tr> \r\n          <td> \r\n            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" bgcolor=\"#EBEBEB\">'),(26,4,'result_loop','            <tr> \r\n                <td width=\"12\"><font size=\"1\" face=\"$pollvars[font_face]\"><img src=\"$pollvars[base_gif]/$poll_color.gif\" width=\"8\" height=\"10\"></font></td>\r\n                <td><font size=\"1\" face=\"$pollvars[font_face]\">$option_text -\r\n                  $vote_val</font></td>\r\n              </tr>'),(27,4,'result_foot','              <tr> \r\n                <td>&nbsp;</td>\r\n                <td><font face=\"$pollvars[font_face]\" size=\"1\">$pollvars[total_text]: \r\n                 <font color=\"#990000\">$total_votes</font><br>\r\n                 $COMMENT&nbsp;</font></td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>'),(28,4,'comment','<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\" bgcolor=\"#666699\">\r\n  <tr align=\"center\">\r\n    <td>\r\n     <style type=\"text/css\">\r\n      <!--\r\n       .button {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}\r\n       .textarea {  font-family: \"MS Sans Serif\"; font-size: 9pt; width: 195px}\r\n       .input {  width: 195px}\r\n      -->\r\n    </style><font color=\"#FFFFFF\" face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"><b>Submit Your Comment</b></font></td>\r\n  </tr>\r\n  <tr>\r\n    <td>\r\n      <table border=\"0\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" bgcolor=\"#FFFFFF\" width=\"200\">\r\n        <tr>\r\n          <td width=\"149\">\r\n            <form method=\"post\" action=\"$this->form_forward\">\r\n              <table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"\" align=\"center\">\r\n                <tr>\r\n                  <td class=\"td1\" height=\"40\"><b><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">$question</font></b></td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Name:</font><br>\r\n                    <input type=\"text\" name=\"name\" maxlength=\"25\" class=\"input\" size=\"23\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">e-mail:</font><br>\r\n                    <input type=\"text\" name=\"email\" size=\"23\" maxlength=\"50\" class=\"input\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Comment(*):</font><br>\r\n                    <font face=\"MS Sans Serif\" size=\"1\">\r\n                    <textarea name=\"message\" cols=\"19\" wrap=\"VIRTUAL\" rows=\"6\" class=\"textarea\"></textarea>\r\n                    </font>\r\n                  </td>\r\n                </tr>\r\n                <tr valign=\"top\">\r\n                  <td>\r\n                    <input type=\"submit\" value=\"Submit\" class=\"button\">\r\n                    <input type=\"reset\" value=\"Reset\" class=\"button\">\r\n                    <input type=\"hidden\" name=\"action\" value=\"add\">\r\n                    <input type=\"hidden\" name=\"id\" value=\"$poll_id\">\r\n                  </td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(29,5,'display_head','<table width=\"450\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"#CCCCCC\">\r\n  <tr>\r\n    <td align=\"center\">\r\n     <style type=\"text/css\">\r\n       <!--\r\n        .input { font-family: $pollvars[font_face]; font-size: 9pt}\r\n       -->\r\n      </style> \r\n      <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" bgcolor=\"#F6F6F6\">\r\n        <tr align=\"center\"> \r\n          <td colspan=\"2\" height=\"40\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><b>$question</b></font></td>\r\n        </tr>\r\n        <tr align=\"center\"> \r\n          <td colspan=\"2\"> \r\n            <form method=\"post\" action=\"$this->form_forward\">\r\n              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\">'),(30,5,'display_loop',' <tr> \r\n   <td width=\"11%\" align=\"center\"><input type=\"radio\" name=\"option_id\" value=\"$data[option_id]\"></td>\r\n   <td width=\"89%\"><font face=\"$pollvars[font_face]\" size=\"1\" color=\"$pollvars[font_color]\">$data[option_text]</font></td>\r\n </tr>'),(31,5,'display_foot','                <tr align=\"center\" valign=\"bottom\"> \r\n                  <td colspan=\"2\"> \r\n                    <input type=\"submit\" value=\"$pollvars[vote_button]\" class=\"input\" name=\"submit\">\r\n                    <input type=\"hidden\" name=\"action\" value=\"vote\">\r\n                    <input type=\"hidden\" name=\"poll_ident\" value=\"$poll_id\">\r\n                  </td>\r\n                </tr>\r\n                <tr valign=\"bottom\"> \r\n                  <td colspan=\"2\" height=\"30\" align=\"center\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">[<a href=\"$this->form_forward?action=results&amp;poll_ident=$poll_id\">$pollvars[result_text]</a>]</font></td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(32,5,'result_head','<table width=\"450\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"#CCCCCC\">\r\n  <tr>\r\n    <td align=\"center\"> \r\n      <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" bgcolor=\"#F6F6F6\">\r\n        <tr align=\"center\"> \r\n          <td colspan=\"3\" height=\"40\"><font face=\"$pollvars[font_face]\" size=\"1\" color=\"#000000\"><b>$question</b></font></td>\r\n        </tr>\r\n'),(33,5,'result_loop','        <tr>\r\n          <td width=\"3%\">&nbsp;</td>\r\n          <td><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$option_text</font></td>\r\n          <td><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\"><img src=\"$pollvars[base_gif]/$poll_color.gif\" width=\"$img_width\" height=\"$pollvars[img_height]\"> $vote_percent % ($vote_count)</font></td>\r\n        </tr>\r\n'),(34,5,'result_foot','        <tr> \r\n          <td colspan=\"3\" valign=\"bottom\" align=\"center\"><b><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$pollvars[total_text]: \r\n            $total_votes</font></b></td>\r\n        </tr>\r\n        <tr align=\"center\"> \r\n          <td colspan=\"3\" valign=\"top\"><font face=\"$pollvars[font_face]\" color=\"$pollvars[font_color]\" size=\"1\">$VOTE \r\n            <br>\r\n            $COMMENT</font></td>\r\n        </tr>\r\n        <tr align=\"right\"> \r\n          <td colspan=\"3\"><font face=\"$pollvars[font_face]\" size=\"1\"><a href=\"http://www.proxy2.de\" target=\"_blank\" title=\"Advanced Poll\">Version $pollvars[poll_version]</a></font></td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(35,5,'comment','<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\" bgcolor=\"#666699\">\r\n  <tr align=\"center\">\r\n    <td>\r\n     <style type=\"text/css\">\r\n      <!--\r\n       .button {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}\r\n       .textarea {  font-family: \"MS Sans Serif\"; font-size: 9pt; width: 195px}\r\n       .input {  width: 195px}\r\n      -->\r\n    </style><font color=\"#FFFFFF\" face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"><b>Send Your Comment</b></font></td>\r\n  </tr>\r\n  <tr>\r\n    <td>\r\n      <table border=\"0\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\" bgcolor=\"#F3F3F3\" width=\"200\">\r\n        <tr>\r\n          <td width=\"149\">\r\n            <form method=\"post\" action=\"$this->form_forward\">\r\n              <table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"\" align=\"center\">\r\n                <tr>\r\n                  <td class=\"td1\" height=\"40\"><b><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">$question</font></b></td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Name:</font><br>\r\n                    <input type=\"text\" name=\"name\" maxlength=\"25\" class=\"input\" size=\"23\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">e-mail:</font><br>\r\n                    <input type=\"text\" name=\"email\" size=\"23\" maxlength=\"50\" class=\"input\">\r\n                  </td>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Comment(*):</font><br>\r\n                    <font face=\"MS Sans Serif\" size=\"1\">\r\n                    <textarea name=\"message\" cols=\"19\" wrap=\"VIRTUAL\" rows=\"6\" class=\"textarea\"></textarea>\r\n                    </font>\r\n                  </td>\r\n                </tr>\r\n                <tr valign=\"top\">\r\n                  <td>\r\n                    <input type=\"submit\" value=\"Submit\" class=\"button\">\r\n                    <input type=\"reset\" value=\"Reset\" class=\"button\">\r\n                    <input type=\"hidden\" name=\"action\" value=\"add\">\r\n                    <input type=\"hidden\" name=\"id\" value=\"$poll_id\">\r\n                  </td>\r\n                </tr>\r\n              </table>\r\n            </form>\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n'),(36,0,'poll_comment','<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" width=\"450\">\r\n  <tr bgcolor=\"#E4E4E4\"> \r\n    <td bgcolor=\"#F2F2F2\"><b><font size=\"1\" face=\"Verdana, Arial, Helvetica, sans-serif\">$data[name]</font></b> \r\n      <i><font size=\"1\" face=\"Verdana, Arial, Helvetica, sans-serif\">$data[email]</font></i> \r\n      - <font size=\"1\" face=\"Verdana, Arial, Helvetica, sans-serif\">$data[time]</font><br>\r\n      <font size=\"1\" face=\"Arial, Helvetica, sans-serif\">$data[host] - $data[browser]</font> \r\n    </td>\r\n  </tr>\r\n  <tr>\r\n    <td><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">$data[message]</font> \r\n    </td>\r\n  </tr>\r\n  <tr> \r\n    <td height=\"15\">&nbsp;</td>\r\n  </tr>\r\n</table>\r\n'),(37,0,'poll_list','<table border=\"0\" cellspacing=\"0\" cellpadding=\"4\" width=\"450\">\r\n  <tr> \r\n    <td width=\"80\" valign=\"top\"> &#0149; <font size=\"2\" face=\"Arial, Helvetica, sans-serif\"><i>$data[timestamp]</i></font></td>\r\n    <td width=\"354\"><font face=\"Arial, Helvetica, sans-serif\" size=\"2\"><a href=\"$PHP_SELF?poll_id=$data[poll_id]\">$data[question]</a></font></td>\r\n  </tr>\r\n</table>\r\n'),(38,0,'poll_form','<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n  <tr> \r\n    <td> \r\n      <style type=\"text/css\">\r\n      <!--\r\n       .button {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}\r\n       .poll_textarea {  font-family: \"MS Sans Serif\"; font-size: 9pt; width: 300px}\r\n       .poll_input {  width: 300px}\r\n      -->\r\n    </style>\r\n      <form method=\"post\" action=\"$this->form_forward\">\r\n        <table border=\"0\" cellspacing=\"0\" cellpadding=\"4\">\r\n          <tr>\r\n            <td class=\"td1\"><font color=\"#CC0000\" face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\"><b>$msg</b></font></td>\r\n          </tr>\r\n          <tr> \r\n            <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Name:</font><br>\r\n              <input type=\"text\" name=\"name\" value=\"$comment[name]\" maxlength=\"30\" class=\"poll_input\" size=\"25\">\r\n            </td>\r\n          </tr>\r\n          <tr> \r\n            <td class=\"td1\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">E-mail:</font><br>\r\n              <input type=\"text\" name=\"email\" value=\"$comment[email]\" size=\"25\" maxlength=\"50\" class=\"poll_input\">\r\n            </td>\r\n          </tr>\r\n          <tr> \r\n            <td class=\"td1\"> <font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Comment:</font><br>\r\n              <font face=\"MS Sans Serif\" size=\"1\"> \r\n              <textarea name=\"message\" cols=\"25\" wrap=\"VIRTUAL\" rows=\"8\" class=\"poll_textarea\">$comment[message]</textarea>\r\n              </font> </td>\r\n          </tr>\r\n          <tr valign=\"top\"> \r\n            <td> \r\n              <input type=\"submit\" value=\"Submit\" class=\"button\" name=\"submit\">\r\n              <input type=\"reset\" value=\"Reset\" class=\"button\" name=\"reset\">\r\n              <input type=\"hidden\" name=\"action\" value=\"add\">\r\n              <input type=\"hidden\" name=\"pcomment\" value=\"$poll_id\">\r\n            </td>\r\n          </tr>\r\n        </table>\r\n      </form>\r\n    </td>\r\n  </tr>\r\n</table>\r\n');
/*!40000 ALTER TABLE `poll_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_templateset`
--

DROP TABLE IF EXISTS `poll_templateset`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_templateset` (
  `tplset_id` int(10) unsigned NOT NULL auto_increment,
  `tplset_name` varchar(50) NOT NULL default '',
  `created` datetime default '0000-00-00 00:00:00',
  PRIMARY KEY  (`tplset_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_templateset`
--

LOCK TABLES `poll_templateset` WRITE;
/*!40000 ALTER TABLE `poll_templateset` DISABLE KEYS */;
INSERT INTO `poll_templateset` (`tplset_id`, `tplset_name`, `created`) VALUES (1,'default','2004-02-19 17:04:49'),(2,'simple','2004-02-19 17:04:49'),(3,'popup','2004-02-19 17:04:49'),(4,'graphic','2004-02-19 17:04:49'),(5,'plain','2004-02-19 17:04:49');
/*!40000 ALTER TABLE `poll_templateset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_user`
--

DROP TABLE IF EXISTS `poll_user`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `poll_user` (
  `user_id` smallint(5) NOT NULL auto_increment,
  `username` varchar(30) NOT NULL default '',
  `userpass` varchar(32) NOT NULL default '',
  `session` varchar(32) NOT NULL default '',
  `last_visit` int(11) NOT NULL default '0',
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `poll_user`
--

LOCK TABLES `poll_user` WRITE;
/*!40000 ALTER TABLE `poll_user` DISABLE KEYS */;
INSERT INTO `poll_user` (`user_id`, `username`, `userpass`, `session`, `last_visit`) VALUES (1,'gnews','ec0cab6c0cb6aa2be5bcb743779923ac','88bca9a5692d3e2d1c60728c5ffb97c8',1217379824);
/*!40000 ALTER TABLE `poll_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2008-08-03  2:05:43
